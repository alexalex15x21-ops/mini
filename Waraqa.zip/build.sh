#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
TOOLS="${WARAQA_TOOLS:-$PWD/.android-tools}"
mkdir -p "$TOOLS/build" "$TOOLS/platform" out/classes
fetch() { if [ ! -f "$2" ]; then curl --fail --location --retry 3 "$1" --output "$2"; fi; }
fetch https://dl.google.com/android/repository/build-tools_r30.0.3-linux.zip "$TOOLS/build.zip"
fetch https://dl.google.com/android/repository/platform-30_r03.zip "$TOOLS/platform.zip"
fetch https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.26.0/ecj-3.26.0.jar "$TOOLS/ecj.jar"
unzip -oq "$TOOLS/build.zip" -d "$TOOLS/build"
unzip -oq "$TOOLS/platform.zip" -d "$TOOLS/platform"
B="$TOOLS/build/android-11"
A="$TOOLS/platform/android-11/android.jar"
"$B/aapt" package -f -M app/src/main/AndroidManifest.xml -S app/src/main/res -A app/src/main/assets -I "$A" -F out/base.apk
java -jar "$TOOLS/ecj.jar" -1.8 -proc:none -classpath "$A" -d out/classes app/src/main/java/app/daftar/MainActivity.java
mapfile -t CLASSES < <(find out/classes -name '*.class')
"$B/d8" --lib "$A" --output out "${CLASSES[@]}"
(cd out && zip -q base.apk classes.dex)
"$B/zipalign" -f 4 out/base.apk out/aligned.apk
# Local test signing only. Not for a Play Store release.
# Rebuilds with another key cannot update the existing installation.
KEY="$TOOLS/test-signing.p12"
if [ ! -f "$KEY" ]; then
 keytool -genkeypair -keystore "$KEY" -storepass android -keypass android -alias waraqa -dname 'CN=Waraqa Prototype' -keyalg RSA -keysize 2048 -validity 3650
fi
"$B/apksigner" sign --ks "$KEY" --ks-pass pass:android --out out/Waraqa-0.3.apk out/aligned.apk
"$B/apksigner" verify --verbose out/Waraqa-0.3.apk
sha256sum out/Waraqa-0.3.apk
