package app.daftar;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends Activity {
 private WebView web;
 private String exportData="";
 private static final String STORE="workbook.json";
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  getWindow().setStatusBarColor(0xff217346);
  getWindow().setNavigationBarColor(0xfff2f2f2);
  web=new WebView(this); setContentView(web);
  WebSettings s=web.getSettings();
  s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);
  s.setAllowFileAccess(false);s.setAllowContentAccess(false);
  s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);
  s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return true;}
  });
  web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new LocalBridge(),"Android");
  try{String html=readLimited(getAssets().open("index.html"),200000);
   web.loadDataWithBaseURL("https://appassets.androidplatform.net/",html,"text/html","UTF-8",null);
  }catch(Exception e){Toast.makeText(this,"تعذر فتح التطبيق",Toast.LENGTH_LONG).show();}
 }
 private static String readLimited(InputStream in,int limit)throws Exception{
  try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
   byte[] buf=new byte[4096];int n;while((n=input.read(buf))!=-1){if(out.size()+n>limit)throw new IOException("too large");out.write(buf,0,n);}return out.toString("UTF-8");
  }
 }
 public class LocalBridge {
  @JavascriptInterface public String load(){try{return readLimited(openFileInput(STORE),5000000);}catch(Exception e){return "";}}
  @JavascriptInterface public synchronized void save(String data){
   if(data.length()>5000000){notice("المصنف كبير جدا. احفظ نسخة احتياطية.");return;}
   try {File tmp=new File(getFilesDir(),STORE+".tmp");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(data.getBytes("UTF-8"));out.getFD().sync();}
    if(!tmp.renameTo(new File(getFilesDir(),STORE)))throw new IOException("rename failed");
   }catch(Exception e){notice("تعذر الحفظ. احفظ نسخة احتياطية.");}
  }
  @JavascriptInterface public void exportFile(final String name,final String type,final String data){runOnUiThread(new Runnable(){public void run(){
   exportData=data;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(type);intent.putExtra(Intent.EXTRA_TITLE,name);
   try{startActivityForResult(intent,100);}catch(Exception e){notice("لا يوجد تطبيق لحفظ الملفات");}
  }});}
  @JavascriptInterface public void importFile(){runOnUiThread(new Runnable(){public void run(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");try{startActivityForResult(i,101);}catch(Exception e){notice("لا يوجد تطبيق لفتح الملفات");}}});}
  @JavascriptInterface public void printSheet(){runOnUiThread(new Runnable(){public void run(){try{PrintManager p=(PrintManager)getSystemService(PRINT_SERVICE);p.print("Waraqa",web.createPrintDocumentAdapter("Waraqa"),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());}catch(Exception e){notice("الطباعة غير متاحة على الجهاز");}}});}
 }
 private void notice(final String text){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,text,Toast.LENGTH_LONG).show();}});}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri u=data.getData();try{
  if(req==100){try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(exportData.getBytes("UTF-8"));}exportData="";notice("تم حفظ الملف");}
  if(req==101){String json=readLimited(getContentResolver().openInputStream(u),5000000);web.evaluateJavascript("loadBackup("+org.json.JSONObject.quote(json)+")",null);}
 }catch(Exception e){notice("تعذر فتح أو حفظ الملف");}}
 @Override protected void onPause(){web.evaluateJavascript("commit()",null);super.onPause();}
 @Override public void onBackPressed(){web.evaluateJavascript("(function(){if(document.getElementById('menu').open){document.getElementById('menu').close();}else{closePanel();}})()",null);}
}
